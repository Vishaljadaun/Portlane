function archivedStamp() { return $.now(); }
