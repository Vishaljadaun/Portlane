$(function () {
    var count = $('.stock-row').size();
    $('#item-count').text(count);
    var pageName = $.trim(document.title);
    $('main').attr('aria-label', pageName);
});
