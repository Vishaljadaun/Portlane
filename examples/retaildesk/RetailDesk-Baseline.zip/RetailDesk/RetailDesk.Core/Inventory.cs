using System.Collections.Generic;
using System.Linq;

namespace RetailDesk.Core
{
    public sealed class StockItem
    {
        public string Name { get; private set; }
        public int OnHand { get; private set; }
        public StockItem(string name, int onHand) { Name = name; OnHand = onHand; }
    }

    public static class Inventory
    {
        public static IList<StockItem> Load()
        {
            return new[] { new StockItem("Packing tape", 2), new StockItem("Shipping labels", 16),
                           new StockItem("Mailers", 5) };
        }
        public static int LowStockCount(int threshold)
        {
            return Load().Count(item => item.OnHand <= threshold);
        }
    }
}
