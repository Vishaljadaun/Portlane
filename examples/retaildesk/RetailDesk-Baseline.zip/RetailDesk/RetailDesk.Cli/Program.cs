using System;
using System.Configuration;
using RetailDesk.Core;

namespace RetailDesk.Cli
{
    class Program
    {
        static void Main()
        {
            int threshold = int.Parse(ConfigurationManager.AppSettings["ReorderThreshold"]);
            Console.WriteLine("Items to reorder: " + Inventory.LowStockCount(threshold));
        }
    }
}
