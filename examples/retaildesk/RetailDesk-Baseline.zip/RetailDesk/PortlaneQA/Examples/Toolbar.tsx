export const Toolbar = () => <span className="float-right">Inventory</span>;
