using System;
using RetailDesk.Core;

namespace RetailDesk.Tests
{
    class Program
    {
        static int Main()
        {
            if (Inventory.LowStockCount(5) != 2 || Inventory.LowStockCount(0) != 0)
            {
                Console.Error.WriteLine("Unexpected reorder count.");
                return 1;
            }
            Console.WriteLine("Both stock checks passed.");
            return 0;
        }
    }
}
