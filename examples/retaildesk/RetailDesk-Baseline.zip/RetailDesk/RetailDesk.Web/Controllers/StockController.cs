using System;
using System.Configuration;
using System.Web.Mvc;
using RetailDesk.Core;

namespace RetailDesk.Web.Controllers
{
    public sealed class StockController : Controller
    {
        public ActionResult Index()
        {
            int visits = Convert.ToInt32(Session["Visits"]) + 1;
            Session["Visits"] = visits;
            ViewBag.VisitCount = visits;
            ViewBag.StoreName = ConfigurationManager.AppSettings["StoreName"];
            return View(Inventory.Load());
        }
    }
}
