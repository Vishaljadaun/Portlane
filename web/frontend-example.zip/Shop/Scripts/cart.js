function countItems() {
    return $('.cart-item').size();
}
function shortLabel(name) {
    return name.substr(0, 12);
}
