// $.now() is documented here only.
const note = "Do not call $.parseJSON(input)";
export const count = items => items.length;
