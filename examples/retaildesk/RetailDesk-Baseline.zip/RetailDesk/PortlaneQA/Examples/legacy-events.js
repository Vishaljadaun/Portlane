function inspectOldHandlers(value, event) {
    var prefix = value.substr(0, 3);
    var timestamp = $.now();
    var row = $.parseJSON('{"item":"Tape"}');
    $('#list').bind('click', refreshList);
    $('#list').unbind('click', refreshList);
    $('.old-item').live('click', refreshList);
    $('.old-item').die('click', refreshList);
    if (event.keyCode === 13) refreshList();
    document.write('Archived demo text');
    return [prefix, timestamp, row];
}
function refreshList() { return true; }
