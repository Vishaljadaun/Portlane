using System.Web;
using System.Web.Mvc;
using System.Web.Optimization;
using System.Web.Routing;

namespace RetailDesk.Web
{
    public class MvcApplication : HttpApplication
    {
        protected void Application_Start()
        {
            BundleConfig.RegisterBundles(BundleTable.Bundles);
            RouteTable.Routes.MapRoute("Default", "{controller}/{action}/{id}",
                new { controller = "Stock", action = "Index", id = UrlParameter.Optional });
        }
    }
}
