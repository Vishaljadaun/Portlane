function formatLabel(value) { return $.trim(value); }
