# RetailDesk
A small ASP.NET MVC 5 stockroom application targeting .NET Framework 4.7.2. The solution includes the web app, a shared stock library, a console summary and an executable test runner. Sample data lives in memory. The legacy web page uses bundled local copies of jQuery 1.12.4 and Bootstrap 3.4.1. The npm manifest represents a separate upgrade trial.

## Try Portlane
1. Upload RetailDesk-Baseline.zip as downloaded. Open Findings and search for size().
2. Choose Explain and preview fix. The replacement fragment is .length. Generate the migration plan and inspect an evidence chip.
3. In Dependencies, follow Views/Stock/Index.cshtml through _ViewStart to the shared layout, then the stock bundle to Scripts/stock.js. Also look for the shared table partial and the local and CDN asset references.
4. In Coverage, compare a regular script, a minified asset, the intentionally broken manifest, the oversized file and the ignored node_modules file.
5. Choose Compare revised ZIP and upload RetailDesk-Revised.zip during the same session. The revision fixes the stock count, retains existing issues, introduces a QA-only $.trim call and removes an archived QA file from the upload. Inspect all four change states. Export the report before refreshing.
6. The synthetic PortlaneQA directory is excluded from every project and from the running site. It includes obsolete calls that are never executed and incomplete JSON for the coverage test. The modern.js example has deprecated names only in a string and a comment.

## Run the application on Windows
Extract the archive. Open RetailDesk.sln in Visual Studio with the ASP.NET and web development workload, IIS Express and the .NET Framework 4.7.2 targeting pack. Restore NuGet packages at solution level and build. Set RetailDesk.Web as the startup project and press F5. Open /Stock/Index. The app lists three stock items, increments the visit counter and opens a help dialog. No database, npm install or API keys are needed.
Alternatively, use a Visual Studio Developer Command Prompt with nuget.exe on PATH:
    nuget restore RetailDesk.sln
    msbuild RetailDesk.sln /p:Configuration=Debug
    RetailDesk.Cli\bin\Debug\RetailDesk.Cli.exe
    RetailDesk.Tests\bin\Debug\RetailDesk.Tests.exe
Expected console result: Items to reorder: 2. The tests print Both stock checks passed and exit with code 0.
Dependencies are restored into packages/. The frontend distribution licenses are in licenses/.
