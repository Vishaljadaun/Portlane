using System.Web.Optimization;

namespace RetailDesk.Web
{
    public static class BundleConfig
    {
        public static void RegisterBundles(BundleCollection bundles)
        {
            bundles.Add(new ScriptBundle("~/bundles/stock").Include("~/Scripts/stock.js"));
            bundles.Add(new StyleBundle("~/bundles/site").Include("~/Content/site.css"));
        }
    }
}
